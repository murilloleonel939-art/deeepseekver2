---
name: security-review
description: Audit code for exploitable security vulnerabilities before they reach production — injection (SQL, command, template, XXE, NoSQL), auth and authorization bypass, XSS, secrets in code, unsafe deserialization, data exposure. Reports only high-confidence findings with file, line, severity, exploit scenario, and fix. Use when the user asks for a security review, a vulnerability audit, to check a site or app for attack surface, or before shipping a release.
---

# Security review

Act as a senior security engineer. Find HIGH-CONFIDENCE security vulnerabilities with real exploitation potential. This is not a general code review: report only security implications, and only those with a concrete attack path.

## 1. Establish scope

Determine what to review from the request:

- **Pending changes** (default when the user says "this branch", "my changes", "the PR", or names nothing): run these with the bash tool and review the diff.
  ```bash
  git status
  git diff --name-only origin/HEAD... 2>/dev/null || git diff --name-only HEAD
  git log --no-decorate origin/HEAD... 2>/dev/null || git log --no-decorate -5
  git diff --merge-base origin/HEAD 2>/dev/null || git diff HEAD
  ```
  If `origin/HEAD` does not resolve, fall back to `git diff HEAD` and `git diff --staged`, and say so in the report.
- **A path or the whole project** (when the user names a directory, "the app", "the site", or "the whole codebase"): walk the tree with the glob and grep tools and read the entry points, routes, data access, auth, and config. Do not attempt a diff.
- **No git repository at all**: review the files directly and skip the diff steps.

State the scope you chose in one line before analysing, so the user can correct it.

## 2. Repository context (phase 1)

Use grep and glob to learn the codebase before judging any file:

- Which security frameworks and libraries are already in use (auth middleware, ORMs, sanitizers, validators).
- The established secure patterns for input handling and output escaping.
- Where the trust boundaries are: what is user input, what is internal, what is server-side only.

## 3. Comparative analysis (phase 2)

Compare the code under review against those established patterns. Flag deviations that introduce a new attack surface, and inconsistent security implementations. A pattern that is safe because of a framework guarantee is not a finding.

## 4. Vulnerability assessment (phase 3)

For each candidate file, trace data flow from user input to sensitive operations, look for privilege boundaries crossed unsafely, and identify injection points and unsafe deserialization.

Categories to examine:

**Input validation** — SQL injection via unsanitized input; command injection in system calls or subprocesses; XXE in XML parsing; template injection in templating engines; NoSQL injection; path traversal in file operations.

**Authentication and authorization** — authentication bypass logic; privilege escalation paths; session management flaws; JWT vulnerabilities (algorithm confusion, missing signature verification, unvalidated claims); authorization logic bypasses.

**Crypto and secrets** — hardcoded API keys, passwords, or tokens that grant access; weak algorithms or implementations; improper key storage; cryptographic randomness issues; certificate validation bypasses.

**Injection and code execution** — RCE via deserialization; pickle injection in Python; YAML `load` deserialization; `eval`/`exec` injection; XSS (reflected, stored, DOM-based) where user input reaches HTML without escaping.

**Data exposure** — sensitive data logging or storage; PII handling violations; API endpoints leaking data; debug information exposure.

A vulnerability exploitable only from the local network can still be HIGH severity.

## 5. Two-pass analysis

**Pass 1 — find.** Dispatch a subagent with the full content of sections 1–4 plus the scope and the file list, and ask it to return candidate vulnerabilities. For a small tree you may analyse directly instead; say which you did.

**Pass 2 — filter.** For each candidate, dispatch a parallel subagent that receives the candidate plus all of section 6 verbatim, and returns whether it survives with a confidence score from 1 to 10. Launch all of these at once rather than one after another.

Then discard every finding whose confidence is below 8.

## 6. False-positive filtering

You do not need to run commands to reproduce a vulnerability; reading the code is enough. Do not write to any files.

HARD EXCLUSIONS — automatically drop findings matching these:

1. Denial of service or resource exhaustion.
2. Secrets or credentials stored on disk if they are otherwise secured.
3. Rate limiting concerns or service overload.
4. Memory consumption or CPU exhaustion.
5. Missing input validation on non-security-critical fields without proven impact.
6. Input sanitization concerns in GitHub Action workflows unless clearly triggerable by untrusted input.
7. Missing hardening measures. Code is not expected to implement every best practice; only concrete vulnerabilities count.
8. Race conditions or timing attacks that are theoretical. Report one only when concretely problematic.
9. Vulnerabilities from outdated third-party libraries — managed separately.
10. Memory safety issues (buffer overflow, use-after-free) in Rust or any memory-safe language.
11. Files that are only unit tests or only used when running tests.
12. Log spoofing. Un-sanitized user input in logs is not a vulnerability by itself.
13. SSRF that only controls the path. SSRF matters only when it controls host or protocol.
14. User-controlled content included in AI system prompts.
15. Regex injection.
16. Regex denial of service.
17. Insecure documentation. Never report findings in markdown or other docs.
18. Absence of audit logs.

PRECEDENTS:

1. Logging high-value secrets in plaintext is a vulnerability. Logging URLs is assumed safe.
2. UUIDs can be assumed unguessable and need no validation.
3. Environment variables and CLI flags are trusted. Any attack relying on controlling them is invalid.
4. Resource management issues (memory or file descriptor leaks) are not valid findings.
5. Subtle low-impact web bugs — tabnabbing, XS-Leaks, prototype pollution, open redirect — are not reported unless extremely high confidence.
6. React and Angular are generally secure against XSS. Do not report XSS in their components or `.tsx` files unless `dangerouslySetInnerHTML`, `bypassSecurityTrustHtml`, or a similar unsafe method is used.
7. Most GitHub Action workflow vulnerabilities are not exploitable in practice. Validate a concrete path first.
8. Missing permission or auth checks in client-side JS/TS is not a vulnerability — the server enforces them, and it is responsible for validating all input.
9. Include MEDIUM findings only when obvious and concrete.
10. Most notebook (`*.ipynb`) vulnerabilities are not exploitable; require a concrete path from untrusted input.
11. Logging non-PII data is not a vulnerability even when the data is sensitive. Only report logging that exposes secrets, passwords, or PII.
12. Command injection in shell scripts is generally not exploitable since such scripts rarely receive untrusted input. Report only with a concrete path.

SIGNAL QUALITY — for each surviving finding, confirm: is there a concrete exploitable vulnerability with a clear attack path; is it a real risk rather than theoretical best practice; are there specific code locations and reproduction steps; would a security team act on it?

## 7. Output

Return the markdown report and nothing else. One section per finding:

```markdown
# Vuln 1: XSS: `foo.py:42`

* Severity: High
* Confidence: 9/10
* Description: User input from the `username` parameter is interpolated into HTML without escaping, allowing reflected XSS.
* Exploit Scenario: An attacker crafts `/bar?q=<script>...</script>` and executes JavaScript in the victim's browser, enabling session hijacking.
* Recommendation: Escape with the framework's `escape()` or a Jinja2 template with auto-escaping enabled for every user value rendered into HTML.
```

Severity: **HIGH** for directly exploitable RCE, data breach, or auth bypass. **MEDIUM** for vulnerabilities needing specific conditions with significant impact. **LOW** for defence-in-depth.

Report HIGH and MEDIUM only. Better to miss a theoretical issue than to flood the report with false positives. If nothing survives filtering, say so plainly and name what you checked — an empty report is a valid, useful result.
